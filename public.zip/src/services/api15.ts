import { axiosPost } from "@/utils/request";

/** 1.5接口 */
export const api15 = `${$config?.api15}`;

/** 获取1.5警车 */
export const queryCar = <T>(data: T) => {
  const url = `${api15}/v2/gps/getCodeByGpsCar`;
  return axiosPost(url, data).then((res: any) => {
    return res?.status?.code === 200 ? res.data || [] : [];
  });
};
