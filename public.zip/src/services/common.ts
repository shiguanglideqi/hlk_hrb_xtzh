import { axiosPost, axiosGet } from "@/utils/request";
import { MenuType } from "./types/common";

/** sso登录 */
export const login = (): Promise<any> => {
  const url = `${$config.api}/system/sso/login`;
  return axiosPost(url, {}).then((res) => {
    return res?.code === 200 ? res.data || {} : {};
  });
};

/** 获取用户资源树 */
export const getResourceTree = (id: string): Promise<MenuType[]> => {
  const url = `${$config.api}/system/userResourceTree/${id}`;
  return axiosGet(url, {}).then((res) => {
    return res?.code === 200 ? res.data || {} : {};
  });
};

/** 通过code 获取字典项 */
export const getDictByCode = async (code: string): Promise<Record<string, string>> => {
  const url = `${$config.api}/dictionary/getDictionaryListByCode/${code}`;
  return axiosGet(url, {}).then((res) => {
    return (res as unknown as Record<string, string>) ?? {};
  });
};
