<template>
  <div class="main-box">
    <div class="text">登录已失效， 请重新登录</div>
  </div>
</template>
<script setup lang="ts"></script>
<style lang="scss" scoped>
.main-box {
  width: 100vw;
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  color: aqua;
}
</style>
