import { useUser } from "@/store";
import { addFollow, deleteFollow, getFollowTypeList } from "./index";

export interface IFollowType {
  id?: string;
  typeName?: string;
}

/**
 * 获取关注分类列表
 * @params {string} type 分类名称
 */
export const useFollowType = (name?: string, type?: string) => {
  const userStore = useUser();

  const typeData = ref<IFollowType[]>([]);

  onMounted(() => {
    getFollowTypeList({ userId: userStore.getUser().id }).then((data) => {
      typeData.value = data || [];
      name && typeData.value.unshift({ id: type || "", typeName: name });
    });
  });

  return {
    typeData,
  };
};

/** 获取关注分类 */
export const getFollowType = (type?: string) => {
  const userStore = useUser();

  const typeData = ref<IFollowType[]>([]);

  return getFollowTypeList({ userId: userStore.getUser().id }).then((data) => {
    typeData.value = data || [];
    type && typeData.value.unshift({ id: "", typeName: type });
    return typeData.value;
  });
};

/** 关注相关 */
export const useFollow = () => {
  /** 添加关注 */
  const follow = <T>(params: T) => {
    return addFollow(params)
      .then((data) => {
        ElMessage.closeAll();
        ElMessage({
          message: "关注成功",
          type: "success",
          offset: 92,
        });
        return data;
      })
      .catch((e) => {
        ElMessage.closeAll();
        ElMessage({
          message: "关注失败",
          type: "error",
          offset: 92,
        });
        console.log("error", e);
      });
  };

  const cancel = <T>(params: T) => {
    return deleteFollow(params)
      .then((data) => {
        ElMessage.closeAll();
        ElMessage({
          message: "取消关注",
          type: "success",
          offset: 92,
        });
        return data;
      })
      .catch((e) => {
        ElMessage.closeAll();
        ElMessage({
          message: "取消关注失败",
          type: "error",
          offset: 92,
        });
        console.log("error", e);
      });
  };

  return {
    /**
     * 添加关注
     */
    follow,
    /** 取消关注 */
    cancel,
  };
};
