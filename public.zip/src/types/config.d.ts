declare const __APP_VERSION__: string;
/** 公用配置 */
declare const $config: any;

declare module "spritesmith";
