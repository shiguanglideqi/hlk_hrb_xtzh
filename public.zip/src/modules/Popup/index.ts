const ClusterPopup = defineAsyncComponent(() => import("./ClusterPopup.vue"));
const DevicePopup = defineAsyncComponent(() => import("./DevicePopup.vue"));

/** Popup 枚举值 */
export enum Popup {
  /** 聚合 */
  Cluster = 10,
  /** 设备：对讲机 警务通 执法记录仪 监控 */
  Device,
  /** 点位详情 */
  Point,
  /** 警车 */
  PoliceCar,
  /** 警员 */
  Constable,
  /** 框选 */
  FrameSelect,
  /** 地址 */
  Address,
  /** 楼栋 */
  Building,
  /** 房屋 */
  HouseInfo,
  /** 警情 */
  Alarm,
  /** 预警 */
  YJ,
  /** 警情 */
  JQ,
  /** 重点人 */
  KeyPerson,
}

export { ClusterPopup, DevicePopup };
