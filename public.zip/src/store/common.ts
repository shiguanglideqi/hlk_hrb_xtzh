interface MapFilterState {
  /** 用于储存135警员idCard及相关数据 */
  idCards: { [key in string]?: any };
}

/** 全局通过状态 */
export const useCommonState = defineStore("useCommonState", {
  state: (): MapFilterState => ({
    idCards: {},
  }),
});
